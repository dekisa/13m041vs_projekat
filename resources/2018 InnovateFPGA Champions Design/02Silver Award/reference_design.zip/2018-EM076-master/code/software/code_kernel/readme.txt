export CROSS_COMPILE=~/gcc-linaro-4.9.4-2017.01-x86_64_arm-linux-gnueabihf/bin/arm-linux-gnueabihf-
export ARCH=arm
export OUT_DIR=~/linux-socfpga-rel_socfpga-4.9.76-ltsi-rt_18.03.01_pr/